//
//  PistatsUserManager.h
//  pistats
//
//  Created by Abhishek on 1/22/16.
//  Copyright © 2016 BluepI. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Users.h"

@interface PistatsUserManager : NSObject

-(BOOL)isValidValue:(NSString *)value;
-(void)onUser:(UIViewController *)view data:(NSDictionary *)userJSON;
-(NSDictionary *)getUserJSON :(Users *)user;
+ (id)getInstance;

@end