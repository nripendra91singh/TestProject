//
//  Constant.h
//  pistats
//
//  Created by Abhishek on 06/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//
#import <Foundation/Foundation.h>
//#import "DeviceInfo.h"
#import "NewEvent.h"
#import <UIKit/UIKit.h>


//#define BaseUrl @"https://3qhqy4xka8.execute-api.us-east-1.amazonaws.com/new_pi_stat_dev/events"
//#define BaseUrl   @"http://54.165.163.242/kinesis/"
#define BaseUrl     @"http://postevents.pi-stats.com/kinesis/"
//#define BaseUrl     @"http://52.3.246.184/kinesis/"
#define BaseUserUrl @"https://3qhqy4xka8.execute-api.us-east-1.amazonaws.com/new_pi_stat_dev/pistatsusers"
#define NotificationConfigurationUrl  @"http://postevents.pi-stats.com/togglenotification"
#define TopicSubscriptionConfigurationUrl  @"http://postevents.pi-stats.com/channelSubscribe"

//************ API URLS ***************

//#define BaseUrl                           @""
#define LocalBaseUrl                        @"http://test-app.pi-stats.com"
//@"http://34.204.81.146"

#define DeviceRegistrationUrl               @"/registration"
#define SubscriptionUrl                     @"/subscription"
#define NotificationSubscriptionONUrl       @"/optIn"
#define NotificationSubscriptionOFFUrl      @"/optOut"
#define PageActivityEventUrl                @"/batchevent"
#define UserEventUrl                        @"/user"
#define ConfigrationUrl                     @"/configuration"
//*************** DeviceInfo **************
#define PiStatsDeviceName                   @"pistatsdevicename"
#define PiStatsBatchLimit                   @"pistatsbatchlimit"
#define PiStatsBatchsize                    @"pistatsbatchsize"
#define PistatsFCMToken                     @"pistatsFCMToken"
#define PistatsLastChannel                  @"pistatsLastChannel"
#define AppFCMToken                         @"appFCMToken"


//************ AppInfo ********************
#define PiStatVersion                       @"1.0"
#define DATA_SYNC_INTERVAL                  60.0
#define DATA_SYNC_INTERVAL_LOAD             300.0

#define DATA_SYNC_LIMIT                     15.0

//*************** Api Task **************
#define PistatsRegistration                 @"pistatsregistration"
#define PistatsSubscribe                    @"pistatssubscribe"
#define PistatsOptIn                        @"pistatsOptIn"
#define PistatsOptOut                       @"pistatsOptOut"
#define PistatsUserCall                     @"pistatsusercall"

//*************** Api Offline Key **************
#define RegistrationAPIKey                 @"registrationApikey"
#define SubscribeAPIKey                    @"subscribeApikey"
#define OptInAPIKey                        @"OptInApikey"
#define OptOutAPIKey                       @"OptOutApikey"
#define UserCallAPIKey                     @"usercallApikey"
#define PushRetryAPIKey                    @"pushretrycallApikey"
#define SubscribeRetryAPIKey               @"subscriberetryApikey"

//***************sync Key **************
#define RegistrationSyncKey                 @"registrationsync"
#define SubscribeSyncKey                    @"subscribesync"
#define OptInOutSyncKey                     @"OptInoutsync"
#define UserCallSyncKey                     @"usersync"
#define SubscribeLatestDataKey              @"subscribelatestDatakey"

#define userDefaults [NSUserDefaults standardUserDefaults]

//***************User Key **************
#define PistatsUserData                 @"pistatsuserdata"
#define PistatsUserLoginID              @"pistatsuserloginid"
#define TimerOn                         @"timeron"
#define RecordInProcess                 @"recordinprocess"
#define RecordNotProcessed              @"recordnotProcessed"

@interface Constant : NSObject
{
         
}

extern NSString * const MOBILE_ACTIVITY_START;
extern NSString * const MOBILE_ACTIVITY_END;
extern NSString * const OS_NAME;
extern NSString * const REFERRER;
extern NSString * const IS_MOBILE;
extern NSString * const PAGE_VISIT;
extern NSString * const  PAGE_EXIT;
extern NSString * const TYPE_DEFAULT;
extern NSString * const TYPE_VIDEO;
extern NSString * const PUSHNOTIFICATION;
extern NSString * const kPiStatsDeviceIdGenratedNotification;
extern NSString * const kPiStatsObserverNotification;
extern NSString *  DEVICE_IOS_ID;
extern NSString *  APPLICATION_NAME;
extern NSString *  BROWSER_VERSION;
extern NSString *  SCREEN_HEIGHT;
extern NSString *  SCREEN_WIDTH;
//extern DeviceInfo  *deviceInfo;
extern NSString *  GUID;
extern NSString *CURRENT_LATITUDE;
extern NSString *CURRENT_LONGITUDE;
extern NSString *CITY;
extern NSString *STATE;
extern NSString *COUNTRY;
extern NSNumber *MEDIA_PLAY;
extern NSNumber *MEDIA_PAUSE;
extern NSNumber *MEDIA_STOP;
extern BOOL IS_CONNECTION;
extern BOOL IS_StartTimer;
extern BOOL IS_AllSubscribeCalled;
extern BOOL IS_AllEventCalled;

extern int regApiCount;
extern int subsApiCount;
extern int optinApiCount;
extern int loadEventApiCount;
extern int subscritionRetryCount;
extern int pushRetryCount;

extern NSInteger batchEventTime;
extern NSInteger subscribeEventTime;





extern NSString * const AUDIO;
extern NSString * const VIDEO;

extern NSString * const LATITUDE_KEY;
extern NSString * const LONGITUDE_KEY;
extern NSString * const CITY_KEY;
extern NSString * const COUNTRY_KEY;
extern NSString * const STATE_KEY;

extern NewEvent * objNewEvent;



//@property (nonatomic,retain) UIViewController *view;

+(NSString *)getcurrentDateinSpecificFormat;
+ (NSMutableDictionary *)deviceInfos;
+ (NSMutableDictionary *)getosInfo;
+(Constant *)getInstance;
+(NSMutableDictionary *)getMobileLocation;
+(NSString *)getKeyValue:(NSDictionary *)customAttributeJSON key:(NSString *)key;
+(NSString *)getExactDurationInSec:(NSNumber *)duration;
+(NSString *)getDurationInSec:(NSString *)duration;
+(BOOL)isKeyRelatedToMedia:(NSString *)key;
+(NSMutableDictionary *)getCustomAttributeJson:(NSDictionary *)customAttributeJson;
+(NSMutableDictionary *)getMediaJSON:(NSDictionary *)customAttributeJSON;
+ (NSString *)guidUserInfo;
+(NSString *)getAppVersionCode;
+(NSString*)getTimestampInString;

//********************** Enum Define Here ********************
typedef NS_ENUM(NSUInteger, PistatsTaskType) {
    kTaskRegistration,
    kTaskSubscribe,
    kTaskOptIN,
    kTaskOptOut,
    kTaskPageLoad,
    kTaskRetry,
    kTaskRetryPushNotification,
    kTaskUserCall,

};


@end
