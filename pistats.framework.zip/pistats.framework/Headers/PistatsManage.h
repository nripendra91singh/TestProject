//
//  PistatsManage.h
//  pistats
//
//  Created by Abhishek on 28/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "Constant.h"
#import "NewEvent.h"

@interface PistatsManage : NSObject<CLLocationManagerDelegate>
{
    Constant *constant;
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
}

@property (nonatomic, retain) CLLocation *currentLocation;



/*Singlton Method of Manager Class. Example
[PistatsManage getInstance]
 */
+(id)getInstance;



/*
Load Analytics Method
NSMutableDictionary *piStateData = [[NSMutableDictionary alloc]init];
[piStateData setValue:@"Your url that need to be track" forKey:@"url"];
[[PistatsManage getInstance] loadController:ControllerObject withCustomAttribute:piStateData];
*/
-(void)loadController:(UIViewController *)view withCustomAttribute:(NSDictionary*)customAttribute;


/*
Notification Enable/Disable Method. Example
[[PistatsManage getInstance]notificationSubscription:YES withFCMToken:@"your fcm token" forSite:@"your specific site id"];
 */
-(void)notificationSubscription:(BOOL)enable withFCMToken:(NSString*)deviceToken forSite:(NSString*)siteID;


/*
 Notification Registration Method. Example
  [[PistatsManage getInstance]registerForApns:@"FCM Token" isNotificationEnable:YES];
 */
-(void)registerForApns:(NSString*)deviceToken isNotificationEnable:(BOOL)enable;



/*
 Notification Topic Subscription  Method on FCM. Example
 */

-(void)unloadController:(UIViewController *)view;
-(void)eventController:(UIViewController *)view eventName:(NSString *)event JSON:(NSDictionary *)customAttribute mediaType:(NSString *)mediaType;
-(void)userIdentity:(UIViewController *)view data:(NSDictionary *)userJSON;

-(void)registerForDevice:(NewEvent*)event;
/*
 Notification Topic Subscription  Method on FCM. Example
 */

-(void)subscribeForNotification:(NewEvent *)event;
/*
 Notification Topic Subscription  Method on FCM. Example
 */
-(void)deviceSwitchOnForNotification:(NewEvent *)event;
-(void)deviceSwitchOffForNotification:(NewEvent *)event;
-(void)loadviewController:(UIViewController *)view WithEvent:(NewEvent *)event;
-(void)postUserData:(NewEvent *)event;
-(void)subscribeAtEveryLaunch;
-(void)subscribeForWrongPushNotification:(NewEvent *)event;
-(void)EventTimer:(NSInteger)loadEventTime WithSubscribe:(NSInteger)subscribeTime;

-(void)postSubscribeRecordAtLaunch;
-(void)postLoadRecordAtLaunch;

@end
