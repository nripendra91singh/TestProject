//
//  PistatsActivityManager.h
//  pistats
//
//  Created by Abhishek on 22/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Load.h"
#import <CoreData/CoreData.h>
#import "CoreDataHelper.h"
#import "NewEvent.h"

 


@interface PistatsActivityManager : NSObject
{
    
}

@property (nonatomic, strong, readonly) CoreDataHelper *coreDataHelper;
 
+ (id)getInstance;
-(void)deleteAll;
-(void)viewOnLoad:(UIViewController *)view withEventValue:(NewEvent*)event;
-(void) startTimer;
-(void) stopTimer;
-(void)userOfflineRequest;
-(void)saveSubscriptiondata:(NSDictionary *)Dict requestURl:(NSString*)Url;
-(NSArray *)fetchSubscribeData;
-(void)deleteSubscribeRecord;
-(NSDictionary*)postPageLoadDictionary;
-(NSArray*)fetchSubscribeAllRecod;
-(void)postRequestForSubscribeAllRecod;
-(void)loadStartTimer;
-(void)loadStopTimer;
-(void)postLoadallEvent;
-(void)postSubscribeallEvent;
-(void)lockDatabaseEventRecord;
@end
