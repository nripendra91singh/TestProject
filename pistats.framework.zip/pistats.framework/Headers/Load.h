//
//  Load.h
//  pistats
//
//  Created by Abhishek on 22/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Load : NSObject

@property(nonatomic,retain) NSString *eventName;
@property(nonatomic,retain) NSString *guid;
@property(nonatomic,retain) NSString *applicationName;
//@property(nonatomic,retain) NSString *OS;
@property(nonatomic,retain) NSString *pageTitle;
@property(nonatomic,retain) NSString *screenHeight;
@property(nonatomic,retain) NSString *screenWidth;
@property(nonatomic,retain) NSString *referrer;
//@property(nonatomic,retain) NSString *pageVisitTimeStamp;
@property(nonatomic,retain) NSMutableDictionary *deviceInfo;
@property(nonatomic,retain) NSMutableDictionary *osInfo;
@property(nonatomic,retain) NSString *isMobile;
@property(nonatomic,retain) NSString *eventType;
@property(nonatomic,retain) NSMutableDictionary *mobileLocation;


//-(NSString *)eventName;
//-(void)setEventName:(NSString *)theEventName;
//
//-(NSString *)guid;
//-(void)setGuid:(NSString *)theGuid;
//
//-(NSString *)applicationName;
//-(void)setApplicationName:(NSString *)theApplicationName;
//
//-(NSString *)OS;
//-(void)setOS:(NSString *)theOS;
//
//-(NSString *)pageTitle;
//-(void)setPageTitle:(NSString *)thePageTitle;
//
//-(NSString *)screenHeight;
//-(void)setScreenHeight:(NSString *)theScreenHeight;
//
//-(NSString *)screenWidth;
//-(void)setScreenWidth:(NSString *)theScreenWidth;
//
//-(NSString *)referrer;
//-(void)setReferrer:(NSString *)theReferrer;
//
//-(NSString *)pageVisitTimeStamp;
//-(void)setPageVisitTimeStamp:(NSString *)thePageVisitTimeStamp;
//
//-(NSString *)deviceInfo;
//-(void)setDeviceInfo:(NSString *)theDeviceInfo;
//
//-(NSString *)isMobile;
//-(void)setIsMobile:(NSString *)theIsMobile;
//
//-(NSString *)mobileLocation;
//-(void)setMobileLocation:(NSString *)theMobileLocation;
//
//-(NSString *)eventType;
//-(void)setEventType:(NSString *)theEventType;
//



@end
