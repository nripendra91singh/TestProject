//
//  User.h
//  pistats
//
//  Created by Abhishek on 08/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Users : NSObject

@property(nonatomic,retain)NSString * guid;
@property(nonatomic,retain)NSString * data;
@property(nonatomic,retain)NSString *firstName;
@property(nonatomic,retain)NSString *lastName;
@property(nonatomic,retain)NSString *name;
@property(nonatomic,retain)NSString *email;
@property(nonatomic,retain)NSString *externalId;
@property(nonatomic,retain)NSString *userName;
@property(nonatomic,retain)NSString *gender;
@property(nonatomic,retain)NSString *profileImageUrl;

@end
