//
//  SubscriptionRequest+CoreDataClass.h
//  pistats
//
//  Created by Nripendra on 06/06/17.
//  Copyright © 2017 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubscriptionRequest : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "SubscriptionRequest+CoreDataProperties.h"
