//
//  NewEvent.h
//  pistats
//
//  Created by Nripendra on 09/05/17.
//  Copyright © 2017 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewEvent : NSObject

@property (nonatomic, strong) NSString   *EventName;
@property (nonatomic, strong) NSArray    *SubscribeToTopics;
@property (nonatomic, strong) NSString   *Language;
@property (nonatomic, strong) NSString   *EventTimestamp;
@property (nonatomic, strong) NSArray    *UnsubscribeFromTopics;
@property (nonatomic, strong) NSString   *FCMToken;
@property (nonatomic, strong) NSString   *UserLoginId;
@property (nonatomic, strong) NSString   *deviceUDID;
@property (nonatomic, strong) NSString   *SocialLoginType;
@property (nonatomic, strong) NSString   *LoginUserID;
@property (nonatomic, strong) NSString   *LoginUserName;
@property (nonatomic, strong) NSString   *LoginUserEmail;
@property (nonatomic, strong) NSString   *LoginUserGender;
@property (nonatomic, strong) NSString   *LoginUserDevID;
@property (nonatomic, strong) NSString   *LoginUserAge;
@property (nonatomic, strong) NSString   *LoginUserCountry;
@property (nonatomic, strong) NSString   *LoginUserState;
@property (nonatomic, strong) NSString   *LoginUserCity;
@property (nonatomic, strong) NSString   *LoginUserLatitude;
@property (nonatomic, strong) NSString   *LoginUserLongitude;
@property (nonatomic, strong) NSString   *ProprtyId;
@property (nonatomic, strong) NSString   *RefererType;         /* Push Notifications, Trending, recommendation, Shyam digest */
@property (nonatomic, strong) NSString   *ReferrerOrigin;      /*piStats, Search, Social, UTM, Internal */
@property (nonatomic, strong) NSString   *ReferrerMedium;
@property (nonatomic, strong) NSString   *ReferrerIndex;
@property (nonatomic, strong) NSString   *ContentID;
@property (nonatomic, strong) NSString   *HomeURl;
@property (nonatomic, strong) NSString   *pistatsGuid;
@end



