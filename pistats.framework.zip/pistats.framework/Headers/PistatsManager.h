//
//  PistatsManager.h
//  pistats
//
//  Created by Abhishek on 02/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PistatsManager : NSObject

+(instancetype) sharedManager;
-(void) startManager;
-(void) stopManager;
-(BOOL) isManagerRunning;
@property (nonatomic) BOOL isEnabled;

@end
