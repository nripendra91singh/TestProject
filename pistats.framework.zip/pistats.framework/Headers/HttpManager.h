//
//  HttpManager.h
//  pistats
//
//  Created by Abhishek on 28/12/15.
//  Copyright © 2015 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PistatsActivityManager.h"
#import "Constant.h"

@protocol HTTPManagerDelegate;

@interface HttpManager : NSObject{
    NSURLConnection *theConnection;
    NSString *URL;
    id <HTTPManagerDelegate> delegate;
    NSMutableData *receiveData;
    NSString *responseString;
    UIViewController *view;
    NSURLConnection *connectionRegistration;
    NSURLConnection *connectionSubscription;
    NSURLConnection *connectionOptIN;
    NSURLConnection *connectionOptOut;
    NSURLConnection *connectionLoadEvent;
    NSURLConnection *connectionUser;
    NSURLConnection *connectionsubRetry;
    NSURLConnection *connectionPushRetry;
}

@property(nonatomic,strong)PistatsActivityManager *activityManager;
@property (nonatomic,retain) NSString *URL;
@property (nonatomic, retain)id <HTTPManagerDelegate> delegate;
@property (nonatomic,retain) NSURLConnection *theConnection;
@property (nonatomic,retain) NSMutableData *receiveData;
@property (nonatomic,retain) NSString *responseString;
@property (nonatomic,retain) UIViewController *view;
@property (nonatomic,retain) NSString  *strStatuscode;

+ (id)getInstance;
//-(void)postRequest:(NSString *)url json:( NSDictionary*)jsonDict controller:(UIViewController *)viewController;
//-(void)postLoadEventRequest:(NSString *)url json:(NSDictionary*)jsonDict controller:(UIViewController *)viewController;
//-(void)postRegistrationRequest:(NSString *)url json:(NSDictionary*)jsonDict controller:(UIViewController *)viewController;
//-(void)postSubscribeRequest:(NSString *)url json:(NSDictionary*)jsonDict controller:(UIViewController *)viewController;
//-(void)postOptInRequest:(NSString *)url json:(NSDictionary*)jsonDict controller:(UIViewController *)viewController;
//-(void)postUserRequest:(NSString *)url json:(NSDictionary*)jsonDict controller:(UIViewController *)viewController;

-(void)postApiCallRequest:(NSString *)url json:(NSDictionary*)jsonDict forTask:(PistatsTaskType)task;


@end
