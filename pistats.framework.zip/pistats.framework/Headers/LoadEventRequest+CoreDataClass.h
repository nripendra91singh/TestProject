//
//  LoadEventRequest+CoreDataClass.h
//  pistats
//
//  Created by Amit Kumar on 12/12/16.
//  Copyright © 2016 BluepI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoadEventRequest : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "LoadEventRequest+CoreDataProperties.h"
