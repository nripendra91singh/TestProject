//
//  LoadEventRequest+CoreDataProperties.h
//  pistats
//
//  Created by Amit Kumar on 12/12/16.
//  Copyright © 2016 BluepI. All rights reserved.
//

#import "LoadEventRequest+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface LoadEventRequest (CoreDataProperties)

+ (NSFetchRequest<LoadEventRequest *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *loadRequestInfo;
@property (nullable, nonatomic, copy) NSNumber *loaddataTimestamp;
@property (nullable, nonatomic, copy) NSString *loadCallState;

@end

NS_ASSUME_NONNULL_END
