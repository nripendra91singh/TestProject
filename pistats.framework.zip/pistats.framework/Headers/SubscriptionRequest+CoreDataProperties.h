//
//  SubscriptionRequest+CoreDataProperties.h
//  pistats
//
//  Created by Nripendra on 06/06/17.
//  Copyright © 2017 BluepI. All rights reserved.
//

#import "SubscriptionRequest+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface SubscriptionRequest (CoreDataProperties)

+ (NSFetchRequest<SubscriptionRequest *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *subsRequest;
@property (nullable, nonatomic, copy) NSString *requestURL;
@property (nullable, nonatomic, copy) NSNumber *dataTimestamp;
@property (nullable, nonatomic, copy) NSString *callState;

@end

NS_ASSUME_NONNULL_END
